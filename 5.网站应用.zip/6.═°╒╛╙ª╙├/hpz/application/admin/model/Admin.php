<?php
namespace app\admin\model;
use think\Model;
/**
* 管理员模型类
*/
class Admin extends Model
{
	/**
	 * 修改管理员密码
	 * @return int 状态码
	 */
	public function modify(){
		//1.获取值
		$id=input('userID');
	    $pwd=md5(input('userPwd'));
		$pwd2=md5(input('userPwd2'));
		
		//2.查询旧密码是否正确
		$pcnt=db('admininfo')->where('userID',$id)->where('userPwd',$pwd)->count();
		if($pcnt!=0) {
	      //修改密码
		   $res=db('admininfo')->where('userID',$id)->update(['userPwd' => $pwd2]);
	       if($res){
	       	return 1; //修改成功
	       }
	    }else{
	    	return 2; //修改失败
	 	}
	}

	/**
	 * 添加管理员
	 * @return int 状态码
	 */
	public function adds(){
		//1.获取值
		$id=input('userID');
		$name=input('userName');
		$pwd=md5(input('userPwd'));
		$roleID=input('userDepart');
		
		//2.查询是否已存在
		$cnt=db('admininfo')->where('userID',$id)->count();
		if($cnt==0){
			//3.添加	
			$data=[
				'userID'=>$id,
				'userPwd'=>$pwd,
				'userName'=>$name,
				'userRoleID'=>$roleID,
			];
			$res=db('admininfo')->insert($data);
			if($res)
			{
				return 1; //添加成功
			}else{
				return 2;  //添加失败
			}
		}else{
			return 3;  //管理员已经存在
			
		}
	}





















}