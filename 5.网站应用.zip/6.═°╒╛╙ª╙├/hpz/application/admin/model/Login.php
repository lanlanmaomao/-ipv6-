<?php
namespace app\admin\model;
use think\Model;
/**
* 登录模型类
*/
class Login extends Model
{
	/**
	 * 验证登录
	 * @return int 状态码
	 */
	public function checkLogin(){
		$res=db('admininfo')->where('userID',input('userID'))->where('userPwd',md5(input('userPwd')))->find();
		if(!empty($res)){
			$userRes=db('admininfo')->field('userName')->where('userID',input('userID'))->find();
			//保存session
			session('userID',input('userID'));
			session('userName',$userRes['userName']);
			return 1; //登录成功
		}else{
			return 2; //登录失败
		}

	}




}