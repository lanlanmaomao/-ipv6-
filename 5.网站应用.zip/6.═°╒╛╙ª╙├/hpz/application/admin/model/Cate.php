<?php
namespace app\admin\model;
use think\Model;
/**
* 类别管理模型类
*/
class Cate extends Model
{
	/**
	 * 查询所有分类
	 * @return array 所有类别
	 */
	public function cateLst(){
		$rows=db('fcate')->order('fCateID asc')->select();
		foreach($rows as $k=>$v){
			$sRows=db('scate')->where('pCateID',$v['fCateID'])->select();
			if($sRows){
				$rows[$k]['child']=$sRows;
			}else{
				$rows[$k]['child']=0;
			}
		}
		return $rows;
	}

	/**
	 * 添加分类
	 * @return int 状态码
	 */
	public function adds(){
		$name=input('bName');
	    $type=input('bType');

		//type==0000说明不属于任何类
		if($type=='0000'){
	    	$data=[
	    		'fCateName'=>$name,
	    	];
	    	$cnt=db('fcate')->insert($data);
		}else{
			$data=[
				'sCateName'=>$name,
				'pCateID'=>$type,
			];
	    	$cnt=db('scate')->insert($data);
	    }

		if($cnt){
			return 1;
		}else{
			return 2;
		}
	}

	/**
	 * 删除分类
	 * @return int 状态码
	 */
	public function del(){
		if(input('fCateID')){
			$flag=db('fcate')->where('fCateID',input('fCateID'))->delete();
			if($flag){
				return 1;
		    }else{
		    	return 2;
		    }
		}
		if(input('sCateID')){
			$flag=db('scate')->where('sCateID',input('sCateID'))->delete();
			if($flag){
				return 1;
			}else{
		    	return 2;
		    }
		}
	}

	/**
	 * 查询单个分类以及子分类的详细信息
	 * @return array 
	 */
	public function beforeModify(){
		if(input('fCateID')){
            $id=input('fCateID');
            $row=db('fcate')->where('fCateID',$id)->find();
            $name=$row['fCateName'];
            $type=0000;
            $res=[
            	'id'=>$id,
            	'name'=>$name,
            	'type'=>$type,
            ];
        }else if(input('sCateID')){
            $id=input('sCateID');
            $row=db('scate')->where('sCateID',$id)->find();
            $name=$row['sCateName'];	           
            $type=$row['pCateID'];
            $res=[
            	'id'=>$id,
            	'name'=>$name,
            	'type'=>$type,
            ];

        }
        return $res;
	}

	/**
	 * 修改分类
	 * @return int 状态码
	 */
	public function modify(){
		$id=input('id');
		$name=input('bName');
	    $type=input('bType');
	    if($type=='0000'){
			$cnt=db('fcate')->where('fCateID',$id)->update(['fCateName'=>$name]);
		}else{
    		$cnt=db('scate')->where('sCateID',$id)->update(['sCateName'=>$name,'pCateID'=>$type]);
		}

		if($cnt!==false){
			return 1;
		}else{
			return 2;
		}
	}












	
}