<?php
namespace app\admin\model;
use think\Model;
/**
*
*/
class News extends Model{

	public function lstNews(){

		if(input('type')){
			$rows=db('newsinfo')->join('fcate','newsFCate = fCateID')->where('newsFCate',input('type'))->order('newsID desc')->paginate(10);
			$srows=db('newsinfo')->join('fcate','newsFCate = fCateID')->where('newsFCate',input('type'))->order('newsID desc')->select();

		}else{
		  //查询全部
			$rows=db('newsinfo')->join('fcate','newsFCate = fCateID')->order('newsID desc')->paginate(10);

			$srows=db('newsinfo')->join('fcate','newsFCate = fCateID')->order('newsID desc')->select();

		}

		foreach($srows as $k=>$v)
		{
			/*判断是否有二级菜单，有子查询*/
			$sRes=db('scate')->where('sCateID',$v['newsSCate'])->value('sCateName');
			if($sRes){
				$srows[$k]['children']=$sRes;
		    }
		}

		$arr[0]=$rows;
		$arr[1]=$srows;

		return $arr;


	}


	public function adds(){
		//1.获取值
			$title=input('newsTitle');
			$fCate=input('fCate');
		    $sCate=input('sCate');
			$from=input('newsFrom');
		    $date=input('newsDate');
		    $color=input('newsColor');
		    $content=input('content_1');
		    $firstPic=$this->getImgs($content,0);
		    $editor=session('userName');


			if($title&&$fCate){
		      //2.添加
				$data = [
				    'newsTitle'=>$title,
				    'newsFCate'=>$fCate,
				    'newsSCate'=>$sCate,
				    'newsFrom'=>$from,
				    'newsPicUrl'=>$firstPic,
				    'newsPicKey'=>'1',
				    'newsDate'=>$date,
				    'newsTitleColor'=>$color,
				    'newsContent'=>$content,
				    'newsEditor'=>$editor,
				];
				// dump($data);
				// die;
				$db=db('newsinfo')->insert($data);
				if($db){
					return 1;
				}

			}else{
				return 2;
		    }

	}

	public  function getImgs($content,$order='ALL'){
	    $pattern="/<img.*?src=[\'|\"](.*?(?:[\.gif|\.jpg]))[\'|\"].*?[\/]?>/";
	    preg_match_all($pattern,$content,$match);
	    if(isset($match[1])&&!empty($match[1])){
	        if($order==='ALL'){
	            return $match[1];
	        }
	        if(is_numeric($order)&&isset($match[1][$order])){
	            return $match[1][$order];
	        }
	    }
	    return '';
	}


	public function addLst(){
		$fres=db('fcate')->order('fCateID asc')->select();
		$sres=db('scate')->order('sCateID asc')->where('pCateID','19')->select();

		$arr[0]=$fres;
		$arr[1]=$sres;
		return $arr;
	}

	public function beforeModify(){
		$id=input('id');
		//查询新闻列表中的id信息
		$nres=db('newsinfo')->where('newsID',$id)->find();
		$fCateID=$nres['newsFCate'];
		$sCateID=$nres['newsSCate'];

		//查询遍历新闻类别
		$fres=db('fcate')->order('fCateID asc')->select();
		//查询遍历新闻相对应的二级类别
		$sres=db('scate')->order('sCateID asc')->where('pCateID',$fCateID)->select();
		//查询相对应id的类别
		$fcate=db('fcate')->where('fCateID',$fCateID)->find();
			//查询相对应id的二级类别
		$scate=db('scate')->where('sCateID',$sCateID)->find();

		$arr['nres']=$nres;
		$arr['fres']=$fres;
		$arr['sres']=$sres;
		$arr['fcate']=$fcate;
		$arr['scate']=$scate;

		return $arr;
	}

	public function modify(){
		$id=input('id');
		$title=input('newsTitle');
		$fCate=input('fCate');
	    $sCate=input('sCate');
		$from=input('newsFrom');
	    $date=input('newsDate');
	    $color=input('newsColor');
	    $content=input('content_1');
	    $firstPic=$this->getImgs($content,0);
	    $editor=session('userName');


		if($title&&$fCate){
	      //2.修改
			$data = [
				'newsID'=>$id,
			    'newsTitle'=>$title,
			    'newsFCate'=>$fCate,
			    'newsSCate'=>$sCate,
			    'newsFrom'=>$from,
			    'newsPicUrl'=>$firstPic,
			    'newsPicKey'=>'1',
			    'newsDate'=>$date,
			    'newsTitleColor'=>$color,
			    'newsContent'=>$content,
			    'newsEditor'=>$editor,
			];
			// dump($data);
			// die;
			$db=db('newsinfo')->update($data);
			if($db!==false){
				return 1;
			}else{
				return 2;
			}


		}else{
			return $this->error('修改内容不能为空！');
	    }
	}










}