<?php
namespace app\admin\controller;
use app\admin\model\News as NewsModel;
/**
* 
*/
class News extends Common{

	//查看新闻
	public function index(){
	    $ts=db('fcate')->order('fCateID asc')->select();
        $this->assign('ts',$ts);
		$news=new NewsModel;

		$arr=$news->lstNews();
		$rows=$arr[0];
		$srows=$arr[1];

		$this->assign('rows',$rows);
		$this->assign('srows',$srows);

		return $this->fetch();
	}

	//删除新闻
	public function del(){
		if(input('delid'))
		{
			$res=db('newsinfo')->where('newsID',input('delid'))->delete();
			if($res){
				$this->success('删除成功','index');
			}
			

		}
	}

	//添加新闻
	public function addNews(){
		
		if(Request()->isPost()){
			$news=new NewsModel;
			$state=$news->adds();
			if($state==1){
				return $this->success('新闻添加成功！','News/index');
			}else{
				return $this->error('新闻添加失败，请填写完整信息');
			}

		}else{
			//如果没有接收到添加新闻的数据
			$news=new NewsModel;
			$arr=$news->addLst();
			$fres=$arr[0];
			$sres=$arr[1];
			$this->assign('fres',$fres);
			$this->assign('sres',$sres);
		}
		
		return $this->fetch();
	}

	//重新生成所有新闻
	public function updateAllNews(){
		return $this->fetch('News/index');
	}
	


    //修改新闻
	public function modifyNews(){
		if(request()->isGet()){
			$news=new NewsModel;
			$arr=$news->beforeModify();
			$nres=$arr['nres'];
			$fres=$arr['fres'];
			$sres=$arr['sres'];
			$fcate=$arr['fcate'];
			$scate=$arr['scate'];
			$this->assign('nres',$nres);
			$this->assign('fres',$fres);
			$this->assign('sres',$sres);
			$this->assign('fcate',$fcate);
			$this->assign('scate',$scate);


		}

		if(request()->isPost()){
			$news=new NewsModel;
			$state=$news->modify();
			if($state==1){
				$this->success('文章修改成功！','News/index');
			}else{
				$this->error('文章修改失败！');
			}
		    
		}

		return $this->fetch();
	}

	
    //根据fcate查询对应的scate,添加ajax下拉菜单二级联动
    public function scateAjax(){
        $pCateID = input('pCateID');
        $res=db('scate')->where("pCateID",$pCateID)->select();
        // $this->ajaxReturn($res,"JSON");
        // $res['sCateName'] = iconv("gbk","utf-8",$res['sCateName']); 

        return json_encode($res);
    }

	 









}