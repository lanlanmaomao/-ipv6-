<?php
namespace app\admin\controller;
/**
* 首页
*/
class Index extends Common
{
	public function index(){
		return $this->fetch();
	}
}