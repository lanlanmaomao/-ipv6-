<?php
namespace app\admin\controller;
use app\admin\model\Admin as AdminModel;
/**
* 管理员类
*/
class Admin extends Common
{
	/**
	 * 查看管理员
	 * @return /Admin/index
	 */
	public function index(){
		$arows=db('admininfo')->paginate(10);
		$this->assign('arows',$arows);
		return $this->fetch();
	}
	
	/**
	 * 修改管理员密码
	 */
	public function modifyUserPwd(){
		if(request()->isPost()){
			$admin=new AdminModel;
			$state=$admin->modify();
			if($state==1){
				$this->success('密码修改成功，请牢记新密码！','Index/index');
			}else{
				$this->error('原密码错误！');
			}
		}
		
		return $this->fetch();

	}

	/**
	 * 添加管理员
	 */
	public function addAdminInfo(){
		//查询所有角色
		$rows=db('userrole')->order('roleID desc')->select();	
		$this->assign('rows',$rows);

		if(request()->isPost()){
			$admin=new AdminModel;
			$state=$admin->adds(); //调用adds()添加数据
			if($state==1){
				$this->success('管理员添加成功','Admin/index');
			}else if($state==2){
				$this->error('管理员添加失败！');
			}else{
				$this->error('该用户已存在，请勿重复提交!');
			}
		}

		return $this->fetch();
	}

	/**
	 * 删除管理员
	 * @return  /Admin/index
	 */
	public function delAdmin(){
		if(input('delid')){
			$res=db('admininfo')->where('userID',input('delid'))->delete();
			if($res){
				$this->success('删除成功','index');
			}else{
				$this->error('删除失败');
			}
		}
		return $this->fetch('Admin/index');

	}






















}