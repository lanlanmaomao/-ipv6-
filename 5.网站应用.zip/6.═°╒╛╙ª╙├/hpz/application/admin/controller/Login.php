<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\Login as LoginModel;
/**
* 用户登录类
*/
class Login extends Controller
{
	/**
	 * 用户登录
	 */
	public function login(){
		//清除session
		session(null);
		$login=new LoginModel;
		if(request()->isPost()){
			$this->check(input('code'));//验证 验证码是否正确
			$state=$login->checkLogin(); //调用checkLogin()方法验证登录
			if($state==1){
				$this->success('登录成功','Index/index');
			}else{
				$this->error('登录失败');
			}
				
		}
		
		return $this->fetch();
	}

	/**
	 * 验证验证码
	 * @return bool
	 */
	public function check($code=''){
		// $captcha = new \think\captcha\Captcha();
		if(!captcha_check($code)){
			$this->error('验证码错误');
		}else{
			return true;
		}
	}

	/**
	 * 退出登录
	 * @return /Login/login
	 */
	public function logout(){
		//清除session
		session(null);
		return $this->fetch('Login/login');
	}




}