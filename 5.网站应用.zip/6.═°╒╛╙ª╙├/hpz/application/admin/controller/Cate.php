<?php
namespace app\admin\controller;
use app\admin\model\Cate as CateModel;
/**
* 类别管理类
*/
class Cate extends Common
{
	/**
	 * 查看所有类别
	 * @return /Cate/index
	 */
	public function index(){
		$cate=new CateModel;
		$rows=$cate->cateLst(); //调用cateLst()查询所有类别
        $this->assign('rows',$rows);
		return $this->fetch();
	}

	/**
	 * 添加类别
	 * @return /Cate/addCate
	 */
	public function addCate(){
		//查询所有一级父类并分配
		$rows=db('fcate')->select();
		$this->assign('rows',$rows);

		if(request()->isPost()){
			$cate=new CateModel;
			$state=$cate->adds();

			if($state==1){
				$this->success('类别添加成功','Cate/index');
			}else{
				$this->error('类别添加失败');
			}
		}


		return $this->fetch();                    
	}

	//删除类别
	public function delCate(){
		$cate=new CateModel;
		$state=$cate->del();
		if($state==1){
			$this->success('类别删除成功！','Cate/index');	
		}else{
			$this->error('类别删除失败');
		}
	}

	//修改类别
	public function modifyCate(){
		if(input('act')){
			$cate=new CateModel;
			$state=$cate->modify();
			if($state==1){
				$this->success('类别修改成功','Cate/index');
			}else{
				$this->error('类别修改失败');
			}
		}else{
			$rows=db('fcate')->select();
			$this->assign('rows',$rows);

			$cate=new CateModel;
			$res=$cate->beforeModify();
	        $this->assign('res',$res);
		}
		
        return $this->fetch();
            
	}














	
}