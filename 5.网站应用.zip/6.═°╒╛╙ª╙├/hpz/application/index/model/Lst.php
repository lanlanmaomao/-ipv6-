<?php
namespace app\index\model;
use think\Model;
class Lst extends Model
{
	public function lstShow(){
		//接收newID
		$newsID=input('newsID');
		//查询newsinfo中的新闻
		$list=db('newsinfo')->where('newsID',$newsID)->find();
		//更新newsinfo中的newsHits字段
		$cdb=db('newsinfo')->where('newsID',$newsID)->update(['newsHits'=>$list['newsHits']+1]);

		$hitcnt=db('newsinfo')->where('newsID',$newsID)->value('newsHits');
        //将查询到的数据赋值给数组
		$arr[0]=$list;
		$arr[1]=$hitcnt;
		return $arr;
	}

	public function base(){
		//接收cID
		$cID=input('cID') ? input('cID') : "8";
		//接收cType
		$cType=input('cType') ? input('cType') : "b";
        //判断cType的类型
		if($cType=='s'){
		  //二级分类
		    $res=db('newsinfo')->where('newsSCate',$cID)->order('newsDate desc')->select();

		    //查询cid下新闻的条数
		    
			$cnt=db('newsinfo')->where('newsSCate',$cID)->count();
			// $this->cnt=$cnt;
		    //对应cid的 一个二级标题
			$nameRes=db('scate')->where('sCateID',$cID)->find();

			$pCateID=$nameRes['pCateID'];

			//二级子菜单对应的一级标题的信息
			$fcate=db('fcate')->where('fCateID',$pCateID)->find();

			//对应一级标题的二级标题集合
			$scate=db('scate')->where('pCateID',$pCateID)->select();

			$name=$nameRes['sCateName'];
			$img=$fcate['fImg'];
			$fName=$fcate['fCateName'];
		}else{
			//按大类查询
			$res=db('newsinfo')->where('newsFCate',$cID)->order('newsDate desc')->select();

			//查询cid下新闻的条数
			$cnt=db('newsinfo')->where('newsFCate',$cID)->count();
			
			//fcate 的一条信息
			$nameRes=db('fcate')->where('fCateID',$cID)->find();
			// $this->fcate=$nameRes;
			//对应一级标题的二级标题集合
			$scate=db('scate')->where('pCateID',$cID)->select();

			$name=$nameRes['fCateName'];
			$img=$nameRes['fImg'];
			$fName=$name;
		}

		$arr['name']=$name;
		$arr['img']=$img;
		$arr['res']=$res;
		$arr['fName']=$fName;
		$arr['scate']=$scate;
		$arr['cnt']=$cnt;
		$arr['fcate']=$nameRes;

		return $arr;
	}


}
