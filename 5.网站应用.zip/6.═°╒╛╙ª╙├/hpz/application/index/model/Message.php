<?php
namespace app\index\model;
use think\Model;
class Message extends Model
{
	public function lst(){
		$name=input('userName');
	    $tel=input('userTel');
	    $msg=input('userMsg');

        $data=[
        	'userName'=>$name,
        	'userTel'=>$tel,
        	'userMsg'=>$msg,
        ];
        $db=db('msginfo')->insert($data);
        if(!empty($db)){
        	return 1;
        }else{
        	return 2;
        }
}















}
