<?php
namespace app\index\controller;
use app\index\model\Lst as LstModel;
class Lst extends Common
{
	private $cnt;
	private $scate;
	private $res;
	private $fcate;
	public function base()
    {
		$base=new LstModel;
		$arr=$base->base();
		$name=$arr['name'];
		$img=$arr['img'];
		$res=$arr['res'];
		$fName=$arr['fName'];
		$scate=$arr['scate'];
		$cnt=$arr['cnt'];
		$nameRes=$arr['fcate'];
		$this->assign('name',$name);
		$this->assign('img',$img);
		$this->assign('res',$res);
		$this->assign('fName',$fName);
		$this->assign('scate',$scate);
		$this->cnt=$cnt;
		$this->res=$res;
		$this->scate=$scate;
		$this->fcate=$nameRes;


    }


    public function index()
    {
    	$this->base();
    	if($this->cnt==1){
    		if(!empty($this->scate)){
    			$this->redirect('Lst/lst', ['cType'=>'s','cID'=>$this->scate[0]['sCateID'],'newsID'=>$this->res[0]['newsID']]);
    		}else{
    			$this->redirect('Lst/lst', ['cType'=>'b','cID'=>$this->fcate['fCateID'],'newsID'=>$this->res[0]['newsID']]);
    		}
    		
    		 
    	}
      	return $this->fetch();
    }




    //新闻详细页
	public function lst(){
		$this->base();
		$lst=new LstModel;
		$arr=$lst->lstShow();
		$hitcnt=$arr[1];
		$list=$arr[0];
		$this->assign('hitcnt',$hitcnt);
		$this->assign('list',$list);
		return $this->fetch();
	}

	


}
