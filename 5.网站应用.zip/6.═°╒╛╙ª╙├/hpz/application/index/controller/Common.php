<?php
namespace app\index\controller;
use think\Controller;


class Common extends Controller
{
	public function _initialize()
    {
        $this->getNavConn();
        $this->sideNav();
        $this->foot();
    }
	public function getNavConn(){
		$navres=db('fcate')->where('fFlag',1)->order('fOrder asc')->select();
		foreach($navres as $k=>$v){
			$sRes=db('scate')->where('pCateID',$v['fCateID'])->select();
			if(!empty($sRes)){
				$navres[$k]['children']=$sRes;
			}else{
				$navres[$k]['children']=0;
			}
		   
		}
	
		return $this->assign('navres',$navres);


	}

	public function sideNav(){
		$id=input("cID");
		//查询新闻大类
		$fRes=db('fcate')->join('newsinfo','fcate.fCateID = newsinfo.newsFCate')->where('newsID',$id)->find();
		$fCateName=$fRes["fCateName"];
		$fCateID=$fRes["fCateID"];
		//echo $sql;
		//查询小类
		
		$res=db('scate')->where('pCateID',$fCateID)->select();
		$html="<h3>".$fCateName."</h3><div class=\"news_type_content\"><ul>";
		if(empty($res)){
		    $html .="<li>该栏目下暂无分类</li>";
		}else {
		    foreach ($res as $row) {
		        $html .= "<li><a href=\"/list/?cType=s&cID=" . $row["sCateID"] . "\">" . $row["sCateName"] . "</a></li>";
		    }
		}
		$html.="</ul></div>";
		
		return $this->assign('sideNav',$html);
	}


	public function foot(){
		//关于我们
		$gywm=db('scate')->where('pCateID',17)->order('sCateID desc')->limit(3)->select();
		$this->assign('gywm',$gywm);

		//新闻资讯
		$xwzx=db('scate')->where('pCateID',19)->order('sCateID desc')->limit(3)->select();
		$this->assign('xwzx',$xwzx);

		//客户服务
		$khfw[0]=db('fcate')->where("fCateID","18")->find();
		$khfw[1]=db('fcate')->where("fCateID","21")->find();
		
		$this->assign('khfw',$khfw);


	}



}