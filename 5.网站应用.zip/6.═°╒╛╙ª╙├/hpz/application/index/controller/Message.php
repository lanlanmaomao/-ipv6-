<?php
namespace app\index\controller;
use app\index\model\Message as MessageModel;

class Message extends Common
{
	//填写留言
    public function index()
    {
    	if(request()->isPost()){
			$this->check(input('userCode'));
		    $message=new MessageModel;
		    $state=$message->lst();
		    if($state==1){
		    	$this->success('留言成功','Message/index');
		    }else{
		    	$this->error('留言失败');
		    }
	       
		}
        return $this->fetch();
    }

    //查看留言
    public function lst(){
    	return $this->fetch('index');
    }


    public function check($code=''){
		// $captcha = new \think\captcha\Captcha();
		if(!captcha_check($code)){
			$this->error('验证码错误');
		}else{
			return true;
		}
	}


	












}
