<?php
namespace app\index\controller;

class Index extends Common
{
    public function index()
    {
    	//产品展示
    	$product=db('newsinfo')->where('newsFcate',18)->limit(6)->select();
    	$this->assign('product',$product);

    	//公司新闻
    	$news=db('newsinfo')->where('newsFcate',19)->limit(6)->select();
    	$this->assign('news',$news);

        return $this->fetch();
    }
}
