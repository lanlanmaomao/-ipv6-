/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : 127.0.0.1:3306
Source Database       : hpz

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2017-09-21 20:32:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admininfo
-- ----------------------------
DROP TABLE IF EXISTS `admininfo`;
CREATE TABLE `admininfo` (
  `userID` varchar(20) NOT NULL,
  `userPwd` varchar(32) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `userDepart` tinyint(4) DEFAULT NULL,
  `userRoleID` tinyint(4) NOT NULL,
  `addDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userID`),
  KEY `fk_roleID` (`userRoleID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of admininfo
-- ----------------------------
INSERT INTO `admininfo` VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', '韩胖子食品', null, '1', '2016-09-08 23:05:46');

-- ----------------------------
-- Table structure for fcate
-- ----------------------------
DROP TABLE IF EXISTS `fcate`;
CREATE TABLE `fcate` (
  `fCateID` int(11) NOT NULL AUTO_INCREMENT COMMENT '一级新闻标题id',
  `fCateName` varchar(20) NOT NULL COMMENT '一级新闻标题名字',
  `fLink` varchar(35) NOT NULL COMMENT '一级栏目链接',
  `fKey` int(11) DEFAULT NULL COMMENT '判断一级栏目是不是有二级栏目,若为1表示没有，0表示有',
  `fFlag` int(255) NOT NULL DEFAULT '1',
  `fOrder` int(255) DEFAULT '0',
  `fImg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fCateID`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of fcate
-- ----------------------------
INSERT INTO `fcate` VALUES ('17', '关于韩胖子', '', null, '1', '0', '/images/t_about.jpg');
INSERT INTO `fcate` VALUES ('18', '产品展示', '', null, '1', '0', '/images/t_product.jpg');
INSERT INTO `fcate` VALUES ('19', '新闻资讯', '', null, '1', '0', '/images/t_news.jpg');
INSERT INTO `fcate` VALUES ('20', '销售网点', '', null, '1', '0', '/images/t_sale.jpg');
INSERT INTO `fcate` VALUES ('21', '招商加盟', '', null, '1', '0', '/images/t_join.jpg');
INSERT INTO `fcate` VALUES ('22', '联系我们', '', null, '1', '0', '/images/t_contact.jpg');
INSERT INTO `fcate` VALUES ('23', '在线留言', '/index/message/index', null, '1', '0', '/images/t_message.jpg');
INSERT INTO `fcate` VALUES ('24', '冷链物流连锁', '', null, '0', '0', null);
INSERT INTO `fcate` VALUES ('25', '熟食连锁', '', null, '0', '0', null);

-- ----------------------------
-- Table structure for msginfo
-- ----------------------------
DROP TABLE IF EXISTS `msginfo`;
CREATE TABLE `msginfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) DEFAULT NULL,
  `userTel` varchar(20) DEFAULT NULL,
  `userMsg` text,
  `addDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of msginfo
-- ----------------------------
INSERT INTO `msginfo` VALUES ('1', '111', '1111', '111', '2016-09-22 22:52:51');

-- ----------------------------
-- Table structure for newsinfo
-- ----------------------------
DROP TABLE IF EXISTS `newsinfo`;
CREATE TABLE `newsinfo` (
  `newsID` int(11) NOT NULL AUTO_INCREMENT COMMENT '新闻ID',
  `newsTitle` varchar(50) NOT NULL COMMENT '简体标题',
  `newsFCate` tinyint(11) NOT NULL COMMENT '所属类别ID 5表示新闻 7表示所属电影  8 表示所属游戏,9表示开心一刻，10表示政府要闻',
  `newsSCate` tinyint(11) DEFAULT NULL COMMENT '小类',
  `newsFrom` varchar(20) DEFAULT NULL COMMENT '新闻来源',
  `newsPicUrl` varchar(200) DEFAULT NULL COMMENT '首页图片',
  `newsPicKey` tinyint(11) DEFAULT NULL COMMENT '首页图片标记',
  `newsContent` text COMMENT '新闻详细内容',
  `newsHits` int(11) DEFAULT '0' COMMENT '点击次数',
  `newsDate` date DEFAULT NULL COMMENT '添加时间',
  `newsEditor` varchar(20) DEFAULT NULL COMMENT '编辑者',
  `newsTitleColor` varchar(11) DEFAULT NULL COMMENT '新闻标题颜色',
  `ip` varchar(15) DEFAULT NULL,
  `newsUrl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`newsID`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of newsinfo
-- ----------------------------
INSERT INTO `newsinfo` VALUES ('85', '联系我们', '22', '0', '本站', '', '1', '<p>全国招商热线：400-0394-777</p><p>免费热线：18939499999</p><p>Email： hpzfoods@126.com</p><p>电 话： 0394-8379999 0394-8379898</p><p>传 真： 0394-8379898</p><p>地 址： 河南省周口市太昊路18号</p><p><br/></p><p><iframe class=\"ueditor_baidumap\" src=\"http://127.0.0.1:1234/admin/utf8-php/dialogs/map/show.html#center=114.698522,33.586481&zoom=15&width=530&height=340&markers=114.700355,33.584676&markerStyles=l,A\" frameborder=\"0\" width=\"534\" height=\"344\"></iframe></p><p><br/></p>', '29', '2016-09-04', '超管', '', '127.0.0.1', 'news20160904003336132.html');
INSERT INTO `newsinfo` VALUES ('88', '河南省韩胖子食品有限公司简介', '17', '26', '本站', '/uploads/20160908/1473350136231726.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160908/1473350136231726.jpg\" title=\"1473350136231726.jpg\" alt=\"com.jpg\"/></p><p>　　河南省韩胖子食品有限公司，总部位于周口市，公司创始人，韩磊，河南省周口市沈丘县人，生于一九八〇年。</p><p>　　1997年韩磊只身去武汉学习卤制品系列产品的技能。</p><p>　　2000年，韩磊回到家乡周口市创业，在周口市文明路创建了第一家韩胖子卤鸭店。</p><p>　　2007年在六一路建设1000平米冷库，除了保证自己的熟食加工外，又开始周口各县市消费者提供安全放心的产品，不仅提高熟食加工的质量，又将鸡鸭冻产品的批发和零售也得到了快速发展。</p><p>　　2010年公司总部入驻周口市南环路黄淮农产品物流园。</p><p>　　2012年注册成立河南省韩胖子食品有限公司，注册资本为2000万元。“韩胖子”商标在国家工商总局注册备案。销售量达到了18000吨，销售额1.6亿元。</p><p>　　2014年10月，公司经过对市场的考察，调研。决定建立韩胖子千镇万村冷链物流连锁网络，利用冷链物流连锁体系，进行冷库连锁，物流配送。</p><p>　　公司被周口市政府授予“放心食品企业”“文明诚信企业”“三A诚信企业”等称号。董事长韩磊被评为周口市“名厨委员会”名誉会长职务，在周口市首届“创业大赛”被授予“创业之星”称号。</p><p><br/></p>', '41', '2016-09-08', '超管', '', '127.0.0.1', 'news20160908154121550.html');
INSERT INTO `newsinfo` VALUES ('90', '品牌优势', '17', '29', '本站', '', '1', '<p>　　“韩胖子”作为河南省熟食业的重点企业，“韩胖子”商标已获得国家商标管理机构审定注册，并获得商标保护权。公司具有丰厚的文化底蕴和强大的品牌号召力。企业将利用自身销售网络优势与成熟的熟食研发技术，截止2012年底已完成200家加盟连锁店的全面改制，计划3年内加盟连锁店达到2000家，立足地方，走向全国，让更多的人品尝的到更美味的地方特色美食。</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>资源优势：</strong></p></li></ul><p>　　公司秉承“质量是韩胖子立命之本”的经营理念，目前已经成功在市场上推出了一百多个系列产品，全部选取安全、合格的生产原料，系列产品进行了全方位的覆盖，适应各个层面的市场要求。</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>专业生产优势：</strong></p></li></ul><p>　　公司集肉类屠宰、研发、熟食生产、加工、销售、配送、连锁加盟一体化。是销售网络健全，系统技术成熟的优质连锁品牌，公司产品辐射全国各地，现有加盟连锁店165家，遍布河南、河北、山东、安徽、北京、上海等13个省市，年产值2.3亿，利税1800万。“韩胖子”经历20多年的市场历练，拥有丰富的熟食连锁店管理运营经验，可向加盟者立体输出，便于快速复制，盈利快。</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>服务创新优势：</strong></p></li></ul><p>　　做食放心，服务用心，精心打造特色化服务。</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>统一形象设计：</strong></p></li></ul><p>　　统一的加盟连锁店店面及形象设计。</p><p><br/></p>', '6', '2016-09-08', '超管', '', '127.0.0.1', 'news20160908154729186.html');
INSERT INTO `newsinfo` VALUES ('89', '企业文化', '17', '27', '本站', '', '1', '<ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>企业精神：</strong></p></li></ul><p>正直诚信、尊重他人、齐心协力、创新拼搏、服务社会；</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>企业使命：</strong></p></li></ul><p>用心做让消费者放心的食品；</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>企业愿景：</strong></p></li></ul><p>提供优质服务，不断创新做人类休闲美食专家；</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>人才理念：</strong></p></li></ul><p>唯才是用、唯德重用、有才有德、破格重用，开心工作，快乐生活；</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>经营理念：</strong></p></li></ul><p>关注客户、不断创新、致力于人才培养、加强合作；</p><p><br/></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: square;\"><li><p><strong>团队文化：</strong></p></li></ul><p>平等互助、分工明确、关系和谐，培养员工主人翁意识。</p><p><br/></p>', '6', '2016-09-08', '超管', '', '127.0.0.1', 'news20160908154455401.html');
INSERT INTO `newsinfo` VALUES ('91', '员工风采', '17', '30', '本站', '/uploads/20160908/1473349801109068.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160908/1473349801109068.jpg\" title=\"1473349801109068.jpg\" alt=\"11.jpg\"/></p><p><br/></p><p>　　韩胖子食品有限公司自1998年在周口成立以来，经历了15年成长历炼，已成长为一家产品硬件设施完善过硬，拥有自主研发兼生产销售完善管理运作系统，在全国拥有近200家门店，遍布河南、河北、山东、安徽、北京、上海等13个省市，目前公司进一步完善和规范自身形象及管理，公司的直营店及专卖店将以崭新、时尚、统一的形象矗立在公众的面前。统一的加盟连锁店店面及柜台形象设计，统一的商标，各类包装盒，手提袋，名片，宣传招贴，店员服装的品牌识别系统。为广大的市民及时尚休闲美食爱好者提供一流的美味及服务。</p><p><br/></p><p style=\"text-align: center;\"><img src=\"/upload/image/20160908/1473349833112708.jpg\" title=\"1473349833112708.jpg\" alt=\"12.jpg\"/></p><p><span style=\"font-family: &#39;Times New Roman&#39;; font-size: 14px; line-height: 30px; background-color: rgb(255, 255, 255);\"><br/></span></p><p>　　韩胖子食品有限公司自1998年在周口成立以来，经历了15年成长历炼，已成长为一家产品硬件设施完善过硬，拥有自主研发兼生产销售完善管理运作系统，在全国拥有近200家门店，遍布河南、河北、山东、安徽、北京、上海等13个省市，目前公司进一步完善和规范自身形象及管理，公司的直营店及专卖店将以崭新、时尚、统一的形象矗立在公众的面前。统一的加盟连锁店店面及柜台形象设计，统一的商标，各类包装盒，手提袋，名片，宣传招贴，店员服装的品牌识别系统。为广大的市民及时尚休闲美食爱好者提供一流的美味及服务。</p>', '4', '2016-09-08', '超管', '', '127.0.0.1', 'news20160908155051418.html');
INSERT INTO `newsinfo` VALUES ('92', '政策支持', '21', '41', '本站', '/uploads/20160908/1473349983687776.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160908/1473349983687776.jpg\" title=\"1473349983687776.jpg\" alt=\"5e2ae0d4-a8c8-4568-bb91-7bb401f3fb3d.jpg\"/></p>', '11', '2016-09-08', '超管', '', '127.0.0.1', 'news20160908155305943.html');
INSERT INTO `newsinfo` VALUES ('93', '市场前景', '21', '42', '本站', '', '1', '<p>　　韩胖子烤鸭、卤鸭系列是一种时尚休闲食品，在中国已有200多年的历史，是老百姓非常喜爱的食品，时尚休息食品行业市场每年以20%增长速度在扩大，目前目标群体已经发展至上至古稀老人下至小孩，不分年纪不分男女都可以食之，针对于不同的消费群，和口味浓度的细分市场，开发不同口味的食品以满足市场才场需求。</p><p><br style=\"white-space: normal; background-color: rgb(255, 255, 255);\"/>　　近几年，随着市场经济的发展，生活水平大大提高，对生活品味的追求更高，人们对休闲美食的需求日夜增加，全国市场前景未来不可估量！</p><p><br style=\"white-space: normal; background-color: rgb(255, 255, 255);\"/>　　众所周知 ，鸭属凉性，经常食之，平肝去火，而配料中辣椒，性温而不燥，除湿去烦，开胃健脾。高蛋白，低脂肪，口感鲜美，肉质细嫩，暖胃生津，益气补湿，辣的过瘾，口味无穷。更具有益气补湿，调节阴阳，降血脂以及养颜美容等功效。</p><p><br style=\"white-space: normal; background-color: rgb(255, 255, 255);\"/>　　韩胖子烤土鸭、鸭脖等，采用散养麻鸭为原料，公司在产品技术上，不断对秘方进行研制和改良，形成自己的核心竞争力，是其他竞争者难以模仿，确保在经营过程中永远立于不败之地。韩胖子烤鸭、卤鸭系列不含防腐剂和色素、无添加，健康实惠。辣嘴不辣喉，越吃越有味，回味无穷。</p>', '4', '2016-09-08', '超管', '', '127.0.0.1', 'news20160908155353480.html');
INSERT INTO `newsinfo` VALUES ('94', '“韩胖子”举行熟食制品加工生产线项目奠基仪式', '19', '38', '本站', '/uploads/20160909/1473350542522233.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473350542522233.jpg\" title=\"1473350542522233.jpg\" alt=\"f9a08f87-872e-435c-ac92-c6678e0c7a1a.JPG\"/></p><p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473350555277339.jpg\" title=\"1473350555277339.jpg\" alt=\"c5fc72fe-5f22-41b5-bd8a-b45eb26404a3.JPG\"/></p><p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473350566371321.jpg\" title=\"1473350566371321.jpg\" alt=\"3a2840c0-ec9d-4614-a72e-61c44ca0fd18.JPG\"/></p><p>　　在各级领导和有关部门的高度重视和亲切关怀下，经过各方的共同努力，河南省韩胖子食品有限公司熟食制品加工生产线项目就要破土动工了。2012年10月20日，市委、市人大、市政府、市政协的各位领导及公司高层管理出席了公司开工奠基仪式并发表致词，奠基仪式取得圆功！<br/></p><p><br/></p><p>　　2012年，公司在河南省周口市经济技术开发区征用50亩地，建设熟食加工生产基地，总投资3800万元 ，一期建成一个生产量达到2万吨的熟食生产加工车间，预计总投资2200万；二期建设两栋职工宿舍楼，预计投资600万；三期建设一个现代化办公楼综合楼，投入资金1000万，主要功能用于加盟店熟食配送和周边省市的冷冻肉食配送、批零、销售，公司实行公司+商户+基地的对接方式，走可持续发展的道路。投产后年购销流量3.2亿元，可安排360人就业，创利税500万元以上。</p><p>　</p><p>　　第二，搞好肉食熟制品的产业开发，依托当地资源优势，利用自有的地方名吃专业技术，走名吃+基地+农户的模式，形成产业链条，实现三方共赢。</p><p><br/></p><p><br/></p><p>　　第三，充分发挥产品特色的延伸和辐射作用，与民族文化，历史文化，人文社会资源相结合，跟随市场经济发展规律，做出地方品牌和地方名吃。</p><p><br/></p>', '6', '2012-10-20', '超管', '', '127.0.0.1', 'news20160908160249632.html');
INSERT INTO `newsinfo` VALUES ('95', '韩胖子爱心白菜：严冬抵不过爱的暖流', '19', '38', '本站', '', '1', '<p>　　2012年12月7号至9号，由河南公共频道《一路有爱》栏目组发起，爱心人士积极参与，帮菜农销售滞销白菜的爱心在行动在郑州市襄河湾生态农业园悄然展开，在持续三天的时间里，来自郑州郑州铭心珠宝 家家欣购物中心 青禾滋补烩面 豫鑫物流 郑州久隆货运 郑州58品牌童装童鞋连锁 泰和源老北京布鞋河南工业大学大学生志愿者 河南省韩胖子食品有限公司等参与了本次活动，希望帮菜农们度过他们心灵的寒冬。</p><p><br/></p><p>　　位于郑州市北郊的襄河湾生态农业园今年的白菜喜获丰收，可菜农们却一脸的苦楚，由于大白菜市场供大于求，导致园区40多万斤的大白菜销售无门，眼看着天气一天天变冷，几十万斤的大白菜却面临在地里冻毁的困境，菜农们眼看着辛辛苦苦忙了一季，原本盼望能买一个好价钱，可如今不但挣不到钱，连种菜的本钱都捞不回来，但再便宜也是菜农们辛辛苦苦种植出来的，如果再卖不出去，他们只能眼巴巴的看着自己的劳动果实烂在地里，此刻，菜农的心就比这寒冷的冬天更寒冷，采访中，我们结识了来自老家南阳的菜农：“我们辛辛苦苦种了几个月，长这么好的蔬菜拦在地里，我们心里很难受，如果今年的菜卖不出去，我们就没钱回家，都要过着流浪的生活，我们心里，一是也没有挣到钱，二是也没有孝敬父母”男儿有泪不轻弹，七尺男儿，眼含着泪花，道出了他心中太多的心酸和无奈；来自开封通许的夫妻俩在这里承包了几十亩菜地，为了把菜种好，他们也几乎没有回过老家，菜园是他们全部的希望，本打算萝卜白菜卖个好价钱，可眼下的困境让他们一筹莫展。</p><p><br/></p><p>　　河南省公共频道《一路有爱》栏目组制片人，知道此事后，发起了出资收购滞销大白菜，免费发放给市民的活动。“爱心在行动，有爱有温暖”，河南豫鑫物流、郑州久隆货运在货运高峰期专门抽出车辆负责蔬菜的免费运送。各大企业爱心人士亲自到菜地里把白菜装上运送车辆。 韩胖子食品公司自1998年在周口成立以来，董事长韩磊就一直不忘回报社会，为当地群众铺路修路，为困难群众捐钱赠衣，寒冬的公益之举微不足道，以后会更加关注公益事业，“把公益越做越好，越做越久。”这次由《一路有爱》发起的爱心活动，他不但出资收购，还不辞辛苦亲自带队，带领公司高层集体到菜地装卸白菜，有这样一位好的带头人，相信公司的事业会在他的带领下越做越红火。</p><p><br/></p>', '4', '2012-12-10', '超管', '', '127.0.0.1', 'news20160908161020160.html');
INSERT INTO `newsinfo` VALUES ('96', '“韩胖子”欢迎新老客户前来洽谈合作，携手共创美好明天！', '19', '38', '本站', '', '1', '<p>　　河南省韩胖子食品有限公司是集肉类熟食生产、加工、销售、配送、连锁加盟及培训管理一体化。是销售网络健全，系统技术成熟的优质连锁品牌，公司产品辐射全国各地，现有加盟连锁店165家，遍布河南、河北、山东、安徽、北京、上海等13个省市，年产值2.3亿，利税1800万。公司熟食生产基地占地32亩，可年生产熏鸡、酱鸭、烤鸭、风味鸡翅、鸡爪、鸡柳等20万吨。公司先后引进了泰国凤爪、韩国烧烤等新产品，利用独家秘方与现代科技相结合，相继开发了麻辣卤制、麻辣酱制、麻辣烧烤等三大系列二十多个单品，是工艺先进、质量稳定、味道独特的河南地方名吃。公司以自身品牌优势为依托，为广大志同道合的美食爱好者提供创业的平台，提供专业的全程化指导，伴您投资创业，让您当月投资，当月赚钱，0风险实现您的创业梦想，与“韩胖子”携手共创美好的明天！</p>', '2', '2013-05-01', '超管', '', '127.0.0.1', 'news20160908161138971.html');
INSERT INTO `newsinfo` VALUES ('97', '传递正能量 “韩胖子”用爱心之举庆店开业', '19', '38', '本站', '/uploads/20160909/1473351484690487.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473351484690487.jpg\" title=\"1473351484690487.jpg\" alt=\"111111111111.jpg\"/></p><p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473351492132038.jpg\" title=\"1473351492132038.jpg\" alt=\"2.jpg\"/></p><p><br/></p><p>　　3月20日上午，河南省韩胖子食品有限公司选择以献爱心的方式庆祝四家新店在郑州开业，引起本地多家媒体及爱心人士的高度关注和一致赞誉。</p><p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473351507261375.jpg\" title=\"1473351507261375.jpg\" alt=\"1.jpg\"/></p><p>　　据悉，当天“火车头爱心车队”及社会的爱心人士，与“韩胖子食品有限公司”员工一起分成3小队，为德全农民工子弟小学、环卫工人和郑州市福利院送去了该公司精心制作的茶香鸭、茶香鸡1000只产品。他们省下数万元广告费，希望用实际的行动为那些需要关注的人群做出一点贡献。</p><p><br/></p><p>　　这次活动，“韩胖子食品有限公司”还针对送达地方的不同，改变平时的“辣味”食品，而是选择了捐赠熟烂易嚼、口味香美的茶香食品。郑州负责人在面对记者“你们以后还会不会继续做公益”的问题时表示，该公司自1998年在周口成立以来，董事长韩磊就一直不忘回报社会，为当地群众铺路修路，为困难群众捐钱赠衣，这次新店开业的公益之举只是一个良好的开始，以后会更加关注郑州的公益事业，“把公益越做越好，越做越久。”</p><p><br/></p><p>　　据了解，河南省韩胖子食品有限公司是河南省熟食业的重点企业，截止2012年底已完成200家加盟连锁店的全面改制，计划3年内加盟连锁店达到2000家，立足地方，走向全国，让更多的人品尝到更美味的地方特色美食。公司秉承“质量是韩胖子立命之本”的经营理念，目前已成功推出十余个系列，一百多种产品，全部选取地方散养麻鸭作为生产原料，对各种口味的卤鸭系列市场进行了全方位的覆盖，适应各个层面的市场要求。</p><p><br/></p>', '2', '2013-03-20', '超管', '', '127.0.0.1', 'news20160908161835478.html');
INSERT INTO `newsinfo` VALUES ('98', '河南省韩胖子食品新店开业暨献爱心活动', '19', '38', '本站', '/ueditor/php/upload/image/20160909/1473351650108026.jpg', '1', '<p>　　2013年9月4日，河南省韩胖子食品有限公司黄河路海滩街门店开业，公司继续以献爱心的方式庆祝新店开业，引起驻豫媒体、当地主流新闻媒体及爱心人士的高度关注和一致赞誉。<br/>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20160909/1473351650108026.jpg\" style=\"padding: 0px; margin: 0px; border: 0px; vertical-align: middle; width: 550px; height: 367px;\"/>&nbsp;</p><p>&nbsp;</p><p>　　中午十时许，载有数百只韩胖子品牌的茶香鸡，茶香鸭和月饼的车子，来到金水区中心敬老院，敬老院的老人们吃着“韩胖子”熟食店员工亲手送上的月饼和茶香鸡鸭，脸上绽放出幸福的笑容。</p><p>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20160909/1473351651122339.jpg\" style=\"padding: 0px; margin: 0px; border: 0px; vertical-align: middle; width: 530px;\"/></p><p style=\"text-align: center;\"><span style=\"font-size: 12px;\">董事长韩磊（图左一）为老人发食品</span></p><p><br/></p><p>　　该公司郑州负责人在面对记者“你们以后还会不会继续做公益”的问题时表示，该公司自1998年在周口成立以来，董事长韩磊就一直不忘回报社会，为当地群众铺路修路，为困难群众捐钱赠衣，这次新店开业的公益之举是又一次很好地关心社会弱势群体，以后还会更加关注郑州的公益事业，“把公益越做越好，越做越久。”<br/>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20160909/1473351652121289.jpg\" style=\"padding: 0px; margin: 0px; border: 0px; vertical-align: middle; width: 530px;\"/></p><p><br/>　　据了解，河南省韩胖子食品有限公司是河南省熟食业的重点企业，截止2012年底已完成200家加盟连锁店的全面改制，计划3年内加盟连锁店达到2000家，立足地方，走向全国，让更多的人品尝到更美味的地方特色美食。公司秉承“质量是韩胖子立命之本”的经营理念，目前已成功推出十余个系列，一百多种产品，选取地方散养麻鸭作为生产原料，对各种口味的卤鸭系列市场进行了全方位的覆盖，适应各个层面的市场要求。<br/>&nbsp;</p><p style=\"text-align: center;\"><img alt=\"\" src=\"/ueditor/php/upload/image/20160909/1473351653109231.jpg\" style=\"padding: 0px; margin: 0px; border: 0px; vertical-align: middle; width: 530px;\"/></p><p><br/></p>', '1', '2013-09-04', '超管', '', '127.0.0.1', 'news20160908162153144.html');
INSERT INTO `newsinfo` VALUES ('99', '韩胖子精美礼盒装上市了 欢迎选购', '19', '38', '本站', '/uploads/20160909/1473351791365554.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473351791365554.jpg\" title=\"1473351791365554.jpg\" alt=\"a07638da-8c06-448c-acbe-6c260b728ab5.jpg\"/></p><p>　　多年来，韩胖子食品深受周口市民的喜爱，甚至走亲访友都会给捎上点，但是因为没有真空包装的礼盒，成为一大憾事，为了感谢广大消费者的喜爱和信赖，至此中秋佳节来临之际，韩胖子改良生产工艺，推出真空包装的礼盒装，可以让真心好滋味传递、分享给所有您挚爱的人，健康、美味给您和您的家人带去一份节日的问候。</p>', '5', '2013-09-15', '超管', '', '127.0.0.1', 'news20160908162313949.html');
INSERT INTO `newsinfo` VALUES ('100', '韩胖子官方微博开通了~~团购优惠进行中~', '19', '38', '本站', '/uploads/20160909/1473351861902204.jpg', '1', '<p>　　韩胖子食品有限公司官方微博开通了，登陆韩胖子新浪微博，随时随地可以了解及分享韩胖子的美味信息，新品上市、打折信息、团购信息一网打尽、、、</p><p><br/></p><p>　　韩胖子真心好滋味！期待你的分享、、、韩胖子（烤土鸭、鸭脖）精美礼品装上架啦！微博预定可享8.5折！</p><p><br/></p><p>　　更多美食折扣尽在美团网和大众点评，中秋节更有逆天优惠，只为让你和家人尽享韩胖子的真心好滋味、、、赶快抢购吧！！~~！</p><p>官方微博地址:<a href=\"http://e.weibo.com/u/3197232837?type=0\" target=\"_blank\">http://e.weibo.com/u/3197232837?type=0&nbsp;</a>&nbsp;</p><p>&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p><p style=\"text-align: center;\"><img src=\"/upload/image/20160909/1473351861902204.jpg\" title=\"1473351861902204.jpg\" alt=\"w.jpg\" width=\"566\" height=\"458\" style=\"width: 566px; height: 458px;\"/></p>', '1', '2013-08-01', '超管', '', '127.0.0.1', 'news20160908162454269.html');
INSERT INTO `newsinfo` VALUES ('101', '家禽业逐步回暖 完全恢复需多方发力', '19', '39', '本站', '', '1', '<p>　　“据不完全统计，人感染H7N9禽流感疫情发生至今，已造成江苏省家禽业直接经济损失46.7亿元，其中商品肉禽损失25.7亿元，种禽损失5.2亿元。”近日，江苏省农委紧急召开全省恢复家禽生产工作会议。</p><p><br/></p><p>　　肉鸡销量减六成，存栏减三成会上，江苏省农委副主任王春喜表示，此次禽流感疫情发生后，居民消费信心严重不足，加之部分地区关闭活禽交易市场、限制交易与流通，禽类产品销售骤减，价格大跌，家禽产业损失巨大。家禽低价抛售、销毁及禽蛋积压严重。到目前为止，黄羽肉鸡销售仍处于基本停滞状态，白羽肉鸡量价齐跌，种禽种雏销毁严重。规模养殖企业商品肉鸡日销量较3月底平均下降60%以上，鸡蛋销量下降40%以上。</p><p><br/></p><p>　　据农业部最新监测数据显示，黄羽肉鸡批发价格每公斤5元，鸡蛋批发价格每公斤6.8元，较4月的最低价每公斤2.8元和每公斤5.7元有所回升，但销量持续低迷，距3月底的最高价每公斤12元和每公斤8元仍有一段距离，消费不振的状况仍将持续一段时间。受此影响，养殖场的养殖积极性普遍受挫，中小规模养殖场和农户低价抛售后空栏不养;一体化企业停孵、销毁种苗种蛋，减少苗禽投放;蛋鸡养殖户因淘汰母鸡销售受阻，影响后备鸡的更新补栏。</p><p><br/></p><p>　　据初步统计，江苏省目前肉禽存栏15956万只，较3月底下降32%。江苏立华牧业有限公司当前商品肉禽存栏较3月底下降四成，累计直接经济损失2.4亿元;江苏京海集团公司的商品肉鸡存栏则下降67%，直接经济损失1.9亿元。</p><p><br/></p><p>　　13市将落实7012万元补贴资金</p><p><br/></p><p>　　在江苏省政府近日召开的专题会上，副省长徐鸣提出恢复市场流通、恢复家禽生产、恢复消费信心的要求。但恢复家禽业生产，困难不少。笔者走访南京多家农贸市场，活禽摊位仍大门紧闭，而宰杀禽类的销量和价格一直在上升，一些消费者仍存在“谈禽色变”的心理。</p><p>　　据了解，盐城家禽业占全省总量的3成-4成，早在5月初，该市已有条件放开光禽交易，并于日前放开活禽交易，但成交不好，量价都上不去。盐城市农委主任茆训东表示，目前，该市190多个炕坊70%停产，苗禽总量较常年减少1300万只。</p><p><br/></p><p>　　“经检疫合格、从正规市场和超市购买的禽产品是安全的。”江苏省动物疫病预防控制中心主任刘耀兴说，禽流感疫情发生以来，农业部门累计排查家禽3.91亿只，未发现重大动物疫情。根据该省政府办公厅恢复家禽市场交易的通知，农业部门将采取多项措施，尤其是尽快将补贴资金发放到位。省农委联合省财政已下拨祖代种禽和加工收储省级补贴资金4781万元。13个市扶持政策也全部出台，落实市级补贴资金7012万元;5月初，南京曾发布消息称，对全市791家活禽经营户减免两个月额摊位费。这笔费用将尽快划拨给经营户。此外，南京、淮安等地协调禽类加工流通企业与中小规模养殖场户对接，扩大活禽加工收储，化解卖禽难。</p><p><br/></p>', '5', '2013-06-08', '韩胖子食品', '', '127.0.0.1', 'news20160909154719837.html');
INSERT INTO `newsinfo` VALUES ('102', '河南一季度畜牧业生产 发展态势总体平稳', '19', '39', '本站', '', '1', '<p>　　6月14日，国家统计局河南调查总队发布统计报告。一季度全省肉蛋奶生产同步增长，畜牧业生产形势总体保持平稳发展。</p><p><br/></p><p>　　据监测调查：一季度全省猪牛羊禽肉产量224.9万吨、禽蛋产量106.9万吨、牛奶产量38.1万吨，与上年同期相比分别增长2.0%、3.3%和4.4%。全省主要畜禽的存、出栏量有增有减。畜禽产品市场供应充足。</p><p><br/></p><p>　　对于今后的工作，统计局专家提出了相关建议：首先要加强监测预警，及时把握生猪生产的新情况、新趋势，引导养猪场户增强市场风险意识，网友建议加强疫病防控，指导养殖场户强化防疫意识，严格落实防疫制度和防控措施，严防疫情发生，加强对生猪龙头企业扩张的宏观指导，引导规模养猪龙头企业在扩张规模时，认真落实扶持生猪生产的各项政策措施。其次要加强指导和支持。科学指导重点畜牧龙头企业合理布局、制订发展规划，研究政策支持措施，帮助企业解决实际困难，促进重点畜牧龙头企业全产业链、全循环发展。充分发挥企业促进生产和稳定市场的作用。</p><p><br/></p>', '7', '2013-06-19', '韩胖子食品', '', '127.0.0.1', 'news20160909154852187.html');
INSERT INTO `newsinfo` VALUES ('105', '韩胖子卤鸭锁骨', '18', '43', '本站', '/hanpangzi/public/uploads/20160921/1474468569109451.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160921/1474468569109451.jpg\" title=\"1474468569109451.jpg\" alt=\"06.jpg\"/></p>', '13', '2016-09-21', '韩胖子食品', '', '127.0.0.1', 'news20160921143634832.html');
INSERT INTO `newsinfo` VALUES ('106', '韩胖子卤豆腐干', '18', '44', '本站', '/hanpangzi/public/uploads/20160921/1474468602630716.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160921/1474468602630716.jpg\" title=\"1474468602630716.jpg\" alt=\"05.jpg\"/></p>', '1', '2016-09-21', '韩胖子食品', '', '127.0.0.1', 'news20160921143655410.html');
INSERT INTO `newsinfo` VALUES ('107', '韩胖子卤鸭头', '18', '45', '本站', '/hanpangzi/public/uploads/20160921/1474468628104463.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160921/1474468628104463.jpg\" title=\"1474468628104463.jpg\" alt=\"04.jpg\"/></p>', '2', '2016-09-21', '韩胖子食品', '', '127.0.0.1', 'news20160921143709124.html');
INSERT INTO `newsinfo` VALUES ('108', '韩胖子卤鸭胗', '18', '46', '本站', '/hanpangzi/public/uploads/20160921/1474468642109898.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160921/1474468642109898.jpg\" title=\"1474468642109898.jpg\" alt=\"03.jpg\"/></p>', '1', '2016-09-21', '韩胖子食品', '', '127.0.0.1', 'news20160921143723658.html');
INSERT INTO `newsinfo` VALUES ('109', '韩胖子卤鸭舌', '18', '47', '本站', '/hanpangzi/public/uploads/20160921/1474468658110978.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160921/1474468658110978.jpg\" title=\"1474468658110978.jpg\" alt=\"02.jpg\"/></p>', '0', '2016-09-21', '韩胖子食品', '', '127.0.0.1', 'news20160921143739468.html');
INSERT INTO `newsinfo` VALUES ('110', '韩胖子卤鸭脖', '18', '48', '本站', '/hanpangzi/public/uploads/20160921/1474468671116999.jpg', '1', '<p style=\"text-align: center;\"><img src=\"/upload/image/20160921/1474468671116999.jpg\" title=\"1474468671116999.jpg\" alt=\"01.jpg\"/></p>', '3', '2016-09-21', '韩胖子食品', '', '127.0.0.1', 'news20160921143752157.html');
INSERT INTO `newsinfo` VALUES ('111', 'hahahahahhaha', '19', '49', '本站', '/hanpangzi/public/uploads/20170920/1505914837165026.jpg', '1', '<p><img src=\"/hanpangzi/public/uploads/20170920/1505914837165026.jpg\" title=\"1505914837165026.jpg\" alt=\"2015040353883057.jpg\"/></p><p><br/></p><p>ahahahhahahahahahha</p>', '23', '2017-09-20', '韩胖子食品', '', null, null);

-- ----------------------------
-- Table structure for scate
-- ----------------------------
DROP TABLE IF EXISTS `scate`;
CREATE TABLE `scate` (
  `sCateID` int(11) NOT NULL AUTO_INCREMENT COMMENT '二级新闻标题id',
  `sCateName` varchar(20) DEFAULT NULL,
  `pCateID` int(11) NOT NULL COMMENT '一级新闻标题名称',
  PRIMARY KEY (`sCateID`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of scate
-- ----------------------------
INSERT INTO `scate` VALUES ('26', '公司简介', '17');
INSERT INTO `scate` VALUES ('27', '企业文化', '17');
INSERT INTO `scate` VALUES ('28', '发展历程', '17');
INSERT INTO `scate` VALUES ('29', '品牌优势', '17');
INSERT INTO `scate` VALUES ('30', '员工风采', '17');
INSERT INTO `scate` VALUES ('38', '公司动态', '19');
INSERT INTO `scate` VALUES ('39', '行业动态', '19');
INSERT INTO `scate` VALUES ('41', '政策支持', '21');
INSERT INTO `scate` VALUES ('42', '市场前景', '21');
INSERT INTO `scate` VALUES ('43', '鸭锁骨', '18');
INSERT INTO `scate` VALUES ('44', '豆腐干', '18');
INSERT INTO `scate` VALUES ('45', '鸭头', '18');
INSERT INTO `scate` VALUES ('46', '鸭胗', '18');
INSERT INTO `scate` VALUES ('47', '鸭舌', '18');
INSERT INTO `scate` VALUES ('48', '鸭脖', '18');

-- ----------------------------
-- Table structure for userrole
-- ----------------------------
DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `roleID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(20) NOT NULL,
  `addDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`roleID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of userrole
-- ----------------------------
INSERT INTO `userrole` VALUES ('1', '系统管理员', '2015-12-06 22:44:21');
INSERT INTO `userrole` VALUES ('2', '网站编辑', '2015-12-06 22:44:25');
