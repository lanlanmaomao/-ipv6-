
// 随机选择背景图
var n=Math.floor(Math.random()*4+1) //0--4
$(".imgBg").attr("src","/hanpangzi/public/static/admin/style/dist/img/bg"+n+".jpg");


$('input').iCheck({
  checkboxClass: 'icheckbox_square-blue',
  radioClass: 'iradio_square-blue',
  increaseArea: '20%' // optional
});