$("#proBeginDate").dateSelect();

{ $("#cp5").colorpicker({ fillcolor:true, event:'mouseover',target:$("#cp5text")});

